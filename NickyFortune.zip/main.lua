if player.charName == "MissFortune" then
	module.load("NickyMissFortune" .. player.charName, "MissFortune")
end