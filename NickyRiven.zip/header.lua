return {
    id = '[Nicky]Riven',
    name = '[Nicky]Riven',
    riot = true,
    type = "Champion",
    load = function()
      return player.charName == 'Riven'
    end
}
